function init(lvl) {
    game.lvl = lvl;
    game.BASE = 2;
    game.toMake = Math.pow(game.BASE, game.lvl);
    game.made = 0;
    game.v = document.querySelector('#val'); //filler
    game.t = document.querySelectorAll('.pbar-text')[0]; //filler text (percentage)
    game.l = document.querySelector('#level')
    game.tg = document.querySelector('#target')
    game.TCl = 0;
    game.p = 0;
    game.t.innerHTML = "0%";

}

$(document).ready(function() {
    $('#nxt').click(function() {
        game.TCl = 0
        game.made = 0;
        game.lvl += 1;
        game.toMake = Math.pow(game.BASE, game.lvl);
        game.p = (game.made / game.toMake) * 100;
        game.v.style.width = '0%';
        game.t.innerHTML = '0%';
        console.log(game)
        if (regi.nick != null || regi.pass != null || regi.email != null) { //user is registered and/or logged
            if (regi.nick != 'x' || regi.pass != 'x' || regi.email != 'x') { //1st user save
                $.ajax({
                    method: "POST",
                    url: "dbwrite.php",
                    complete: function(){
                        localStorage.setItem('isInDB', true); //tells server that user's 1st save has been done 
                    },
                    data: { nick: regi.nick, email: regi.email, pass: regi.pass, level: game.lvl, tc: game.TC }
                });
            } else { //if it isn't 1st save, do
                regi.nick = localStorage.getItem('login');
                regi.pass = localStorage.getItem('pass');
                regi.email = localStorage.getItem('email');
                $.ajax({
                    method: "POST",
                    url: "dbupdate.php",
                    complete: function(){
                    regi.nick = regi.pass = regi.email = 'x'; //tells server that user's 1st save has been done 
                    },
                    data: { level: game.lvl, tc: game.TC }
                });
            }
        } else {
            snsa(lf);
            addClass(lf, 'fade');
        }
    });
    $('#button').click(function() {
        if (game.TCl == 0) {
            game.made += game.BASE;
            game.l.innerHTML = "Your level: " + game.lvl;
            game.tg.innerHTML = game.made + " of " + game.toMake;
            game.p = (game.made / game.toMake) * 100;
            game.v.style.width = game.p + '%';
            game.t.innerHTML = Math.round(game.p) + '%';
            if (game.made != game.toMake) {
                game.TCl += 1;
                game.TC += 1;
                console.log(game);
            } else {
                game.TCl += 1;
                game.TC += 1;
                game.t.innerHTML = "Next Level <a id='nxt' href='#' onclick=init(" + (game.lvl + 1) + ")>=></a>";
                console.log(game)
            }
        } else {
            if (game.made != game.toMake) {
                game.made *= game.BASE;
                game.l.innerHTML = "Your level: " + game.lvl;
                game.tg.innerHTML = game.made + " of " + game.toMake;
                game.p = (game.made / game.toMake) * 100;
                game.v.style.width = game.p + '%';
                game.t.innerHTML = Math.round(game.p) + '%';
                if (game.made != game.toMake) {
                    game.TCl += 1;
                    game.TC += 1;
                    console.log(game)
                } else {
                    game.TCl += 1;
                    game.TC += 1;
                    game.t.innerHTML = "Next Level <a id='nxt' href='#' onclick=init(" + (game.lvl + 1) + ")>=></a>";
                    console.log(game)
                }
            }
        }
    });
    window.game = {}
    var game = window.game;
    game.TC = 0;
    initauth();
    init(1)
});