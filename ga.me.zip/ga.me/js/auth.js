function initreg() {
    document.querySelector('.regbtn').onclick = function() {
        var lr = document.querySelector('#lr').value;
        var pr = document.querySelector('#pr').value;
        var emr = document.querySelector('#emr').value;
        reg(lr, pr, emr);
        setTimeout(function() {
            hnra(rf)
        }, 3000);
    }
    console.info('Registering initialised!')
}

function initauth() {
    initlog();
    initreg();
    window.regi = {};
    var regi = window.regi;
    if (window.localStorage.length == 0) {
        regi.nick = regi.pass = regi.email = null;
    } else if (localStorage.getItem('isInDB')) {
        regi.nick = regi.pass = regi.email = 'x';
    } else {
        regi.nick = localStorage.getItem('login');
        regi.pass = localStorage.getItem('pass');
        regi.email = localStorage.getItem('email');
    }


}

function initlog() {
    document.querySelector('.logbtn').onclick = function() {
        var ll = document.querySelector('#ll').value;
        var pl = document.querySelector('#pl').value;
        var eml = document.querySelector('#eml').value;
        log(ll, pl, eml);
        setTimeout(function() {
            hnra(lf)
        }, 3000);
    }
    console.info('Logining initialised!')
}

function reg(log, pass, email) {
    localStorage.clear();
    var ln = forge.md.sha512.create();
    var pw = forge.md.sha512.create();
    var em = forge.md.sha512.create();
    ln.update(log);
    regi.nick = ln.digest().toHex();
    localStorage.setItem('login', regi.nick);
    pw.update(pass);
    regi.pass = pw.digest().toHex();
    localStorage.setItem('pass', regi.pass);
    em.update(email);
    regi.email = em.digest().toHex();
    localStorage.setItem('email', regi.email);
    console.info('Registered!!')
}

function log(log, pass, email) {
    var ln = forge.md.sha512.create();
    var pw = forge.md.sha512.create();
    var em = forge.md.sha512.create();
    ln.update(log);
    pw.update(pass);
    em.update(email);
    var clog = ln.digest().toHex();
    var cpass = pw.digest().toHex();
    var cemail = em.digest().toHex();
    if (clog != localStorage.getItem('login')) {
        throwError();
    } else if (cpass != localStorage.getItem('pass')) {
        throwError()
    } else if (cemail != localStorage.getItem('email')) {
        throwError()
    } else {
        throwSuccess()
    }
}


function throwError() {
    console.error('Error!!')
    var econt = document.querySelector('#ec');
    remNAdd(econt, 'err');
    show(econt);
    econt.innerHTML = '<span class="ect">Error! Please verify specified data and try again.</span>';
}

function throwSuccess() {
    console.info('Success!!!')
    var econt = document.querySelector('#ec');
    remNAdd(econt, 'tick');
    show(econt);
    econt.innerHTML = '<span class="ect">Success!</span>';
}