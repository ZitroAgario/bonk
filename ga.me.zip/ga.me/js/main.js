function globalInit() {
    initauth();
    hmoc();
}