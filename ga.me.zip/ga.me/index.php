<!DOCTYPE HTML>
<html lang="ru-RU">

<head>
    <title>Cool game</title>
    <meta charset="Windows-1251">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="js/forge.js"></script>
    <script src="js/helps.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/btns.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
    <link rel="stylesheet" type="text/css" href="css/anims.css" media="all">
    <link rel="stylesheet" type="text/css" href="css/style.css" media="all">
    <link rel="stylesheet" type="text/css" href="css/main.css" media="all">
</head>

<body>
    <button class="ald autow" id="logbtn">
        Login!
    </button>
    <button class="ald autow" id="regbtn">
        Register!
    </button>
    <div id="rf" class="modal">
        <div class="modal-content">
            <span class="x" onclick="hnra(rf)" title="Close Form">&#10060;</span><br>
            <div id="reg" class="cont">
                <input type="text" autocomplete="on" name="login" placeholder="Put your login there" id="lr"><br>
                <input type="password" autocomplete="on" name="password" placeholder="Put your password there" id="pr"><br>
                <input type="email" autocomplete="email" name="email" placeholder="Put your email there" id="emr"><br>
                <div class="clearfix">
                    <button class="cnlbtn">
                        		Cancel
                    		</button>
                    <input type="submit" class="regbtn" id="snup" value="Register">
                </div>
            </div>
        </div>
    </div>
    <div id="lf" class="modal">
        <div class="modal-content">
            <span class="x" onclick="hnra(lf)" title="Close Form">&#10060;</span><br>
            <div id="log" class="cont">
                <input type="text" autocomplete="on" name="login" placeholder="Put your login there" id="ll"><br>
                <input type="password" autocomplete="on" name="password" placeholder="Put your password there" id="pl"><br>
                <input type="email" autocomplete="email" name="email" placeholder="Put your email there" id="eml"><br>
                <div id="ec"></div><br>
                <div class="clearfix">
                    <button class="cnlbtn">
                        		Cancel
                    		</button>
                    <input type="submit" class="logbtn" id="snin" value="Login">
                </div>
            </div>
        </div>
    </div>
    <div style="margin-left: 33%;">
        <div id='pbar' data-binary='100'>
            <div id='val'>
                <span class='pbar-text'></span>
            </div>
        </div>
    </div>
    <div style="margin-left: 40%;">
        <img src="img/png/pointer.png" width="170px" height="210px" alt="Click me!" id='button'>
        <br>
        <div style="margin-left: 20px;">
            <h1 id='level'></h1>
        </div>
        <div style="margin-left: 40px;">
            <h1 id='target'></h1>
        </div>
        <div id='error'></div>

    </div>
</body>

</html>