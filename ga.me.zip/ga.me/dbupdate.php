<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "game"; 
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if (mysqli_connect_errno())
	{
		$e = mb_convert_encoding(mysqli_connect_error(), "UTF-8");
		echo "Failed to connect to MySQL: " . $e;
		exit();
	}//Connection created
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$nick=test_input($_POST['nick']);
		$level=test_input($_POST['level']);
		$tc=test_input($_POST['tc']);
	}
	//Variables initialised
	function test_input($data) { 
	    $data = trim($data); 
	    $data = stripslashes($data); 
	    $data = htmlspecialchars($data);
		return $data; 
	}
	$sql="UPDATE game SET level='$level', tc='$tc' WHERE nick='$nick';";
	mysqli_query($conn, $sql) or die(mysqli_error($conn));
?>