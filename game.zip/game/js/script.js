


	function init(lvl)
	{
	  game.lvl=lvl;
	game.BASE = 2;
	game.toMake = Math.pow(game.BASE,game.lvl);
	game.made = 0; 
	game.v = document.getElementById('val');//filler
	game.t = document.getElementsByClassName('pbar-text')[0];//filler text (percentage)
	game.n = document.getElementById('number')
	game.TCl = 0;
	game.p = 0;
	game.t.innerHTML = "&nbsp";
	$('#nxt').click(function(){
		game.TCl=0
		game.made = 0;
		game.lvl+=1;
		game.toMake = Math.pow(game.BASE,game.lvl);
		game.p = (game.made/game.toMake)*100;
		game.v.style.width ='0%';
		game.t.innerHTML = '';
		console.log(game)
	});
	$('#button').click(function(){
		if (game.TCl==0){
			game.made+=game.BASE;
			game.n.innerHTML=game.made;
			game.p = (game.made/game.toMake)*100;
			game.v.style.width = game.p+'%';
			game.t.innerHTML = Math.round(game.p)+'%';
			if(game.made!=game.toMake){
				game.TCl+=1;
				game.TC+=1;
				console.log(game);
			}else{
				game.TCl+=1;
				game.TC+=1;
				game.t.innerHTML = "Next Level <a id='nxt' href='#' onclick=init("+(game.lvl+1)+")>=></a>";
				console.log(game)
			}
		}else{
			if(game.made!=game.toMake){
				game.made *= game.BASE;
				game.n.innerHTML=game.made;
				game.p = (game.made/game.toMake)*100;
				game.v.style.width = game.p+'%';
				game.t.innerHTML = Math.round(game.p)+'%';
				if(game.made!=game.toMake){
					game.TCl+=1;
					game.TC+=1;
					console.log(game)
				}else{
					game.TCl+=1;
					game.TC+=1;
					game.t.innerHTML = "Next Level <a id='nxt' href='#' onclick=init("+(game.lvl+1)+")>=></a>";
					console.log(game)
				}
			}
		}
	});	
	}
$( document ).ready(function() {
	window.game={}
	var game=window.game;
	game.TC=0;
	init(1)
});