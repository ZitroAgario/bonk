

$( document ).ready(function() {
	var lvl = 6;
	var BASE = 2;
	var toMake = Math.pow(BASE,lvl);
	var made = BASE; 
	var val = document.getElementById('pbar').getAttribute('data-binary');//number of percents to do (100 by default)
	var v = document.getElementById('val');//filler
	var t = document.getElementsByClassName('pbar-text')[0];//filler text (percentage)
	var p = 0;
	t.innerHTML = "&nbsp";
	$('#nxt').click(function(){
		made = BASE;
		++lvl;
		var toMake = Math.pow(BASE,lvl);
		p = (made/toMake)*100;
		v.style.width = p+'%';
		t.innerHTML = p+'%';
		console.log(p,v.style.width,made,toMake)
	});
	$('#button').click(function(){
		if(made!=toMake){
			made *= 2;
			p = (made/toMake)*100;
			v.style.width = p+'%';
			t.innerHTML = p+'%';
			console.log(p,v.style.width,made,toMake)
		}else{
			t.innerHTML = "Next Level <a id='nxt' href='#'>=></a>";
			console.log(p,v.style.width,made,toMake)
		}
	});

});